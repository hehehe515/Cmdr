---
title: Cmdr
docs:
  tags:
    - server only
  properties:
    - name: Registry
      type: Registry
      desc: Refers to the current command Registry.
    - name: Dispatcher
      type: Dispatcher
      desc: Refers to the current command Dispatcher.
    - name: Util
      type: Util
      desc: Refers to a table containing many useful utility functions.
---

<ApiDocs />