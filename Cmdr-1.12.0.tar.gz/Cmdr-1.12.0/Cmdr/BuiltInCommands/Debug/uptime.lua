return {
	Name = "uptime";
	Aliases = {};
	Description = "Returns the amount of time the server has been running.";
	Group = "DefaultDebug";
	Args = {};
}